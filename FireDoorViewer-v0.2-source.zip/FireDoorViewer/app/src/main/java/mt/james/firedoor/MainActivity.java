package mt.james.firedoor;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    EditText stream, token;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,24,28,24);
        TextView title = new TextView(this); title.setText("Fire Door Viewer • prototype 0.2\nLAN listener: port 7980 • VLC playback"); title.setTextSize(21); box.addView(title);

        stream = new EditText(this); stream.setId(View.generateViewId()); stream.setSingleLine(); stream.setHint("RTSP stream URL");
        stream.setText(getPreferences(0).getString("stream", "rtsp://192.168.1.233:8556/aqara_g410_clean")); box.addView(stream);
        token = new EditText(this); token.setId(View.generateViewId()); token.setSingleLine(); token.setHint("Secret token (at least 12 characters)");
        token.setText(getPreferences(0).getString("token", "")); token.setFocusable(true); token.setFocusableInTouchMode(true); box.addView(token);
        Button save = new Button(this); save.setId(View.generateViewId()); save.setText("Save and start listener"); box.addView(save);
        Button test = new Button(this); test.setId(View.generateViewId()); test.setText("Test 30-second overlay"); box.addView(test);

        stream.setNextFocusDownId(token.getId());
        token.setNextFocusUpId(stream.getId()); token.setNextFocusDownId(save.getId());
        save.setNextFocusUpId(token.getId()); save.setNextFocusDownId(test.getId());
        test.setNextFocusUpId(save.getId());

        TextView note = new TextView(this); note.setText("Uses bundled VLC for RTSP/H.264 playback.\nRequires 'Display over other apps' permission.\nKeep this app's service running for HA commands."); box.addView(note);
        setContentView(box);

        save.setOnClickListener(v -> {
            if (token.getText().toString().trim().length()<12) { Toast.makeText(this,"Use a token of at least 12 characters",Toast.LENGTH_LONG).show(); return; }
            getPreferences(0).edit().putString("stream",stream.getText().toString().trim()).putString("token",token.getText().toString().trim()).apply();
            if (!Settings.canDrawOverlays(this)) { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))); return; }
            startService(new Intent(this,DoorService.class)); Toast.makeText(this,"Listener started",Toast.LENGTH_SHORT).show();
        });
        test.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) { Toast.makeText(this,"Grant overlay permission first",Toast.LENGTH_LONG).show(); return; } startService(new Intent(this,DoorService.class).setAction("SHOW")); });
    }
}
