package mt.james.firedoor;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;

public class DoorService extends Service {
    private static final int PORT=7980;
    private ServerSocket server;
    private final ExecutorService workers=Executors.newCachedThreadPool();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private WindowManager wm; private View overlay; private SurfaceView surface;
    private LibVLC libVLC; private MediaPlayer player;
    private final Runnable hide=this::removeOverlay;

    @Override public void onCreate() {
        super.onCreate();
        Notification.Builder nb=new Notification.Builder(this).setContentTitle("Fire Door Viewer")
                .setContentText("Waiting for Home Assistant").setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT));
        startForeground(101,nb.build());
        workers.execute(this::listen);
    }
    @Override public int onStartCommand(Intent intent,int flags,int id) {
        if(intent!=null && "SHOW".equals(intent.getAction())) ui.post(() -> show(30));
        if(intent!=null && "HIDE".equals(intent.getAction())) ui.post(this::removeOverlay);
        return START_STICKY;
    }
    private void listen() {
        try (ServerSocket ss=new ServerSocket()) {
            server=ss; ss.setReuseAddress(true); ss.bind(new InetSocketAddress(PORT));
            while(!ss.isClosed()) { Socket s=ss.accept(); s.setSoTimeout(2500); workers.execute(() -> request(s)); }
        } catch(Exception e) { android.util.Log.e("FireDoor","Listener stopped",e); }
    }
    private void request(Socket s) {
        try (Socket socket=s) {
            BufferedReader br=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String line=br.readLine(); if(line==null) return;
            String path=line.split(" ")[1]; while ((line=br.readLine())!=null && !line.isEmpty()) {}
            String configured=getSharedPreferences("MainActivity",0).getString("token","");
            String supplied=""; int i=path.indexOf("token="); if(i>=0) supplied=URLDecoder.decode(path.substring(i+6).split("&")[0],"UTF-8");
            boolean allowed=configured.length()>=12 && constantTime(configured,supplied);
            String body; int status;
            if(!allowed){status=403;body="Forbidden";}
            else if(path.startsWith("/show?")){status=200;body="Showing";ui.post(() -> show(60));}
            else if(path.startsWith("/hide?")){status=200;body="Hiding";ui.post(this::removeOverlay);}
            else{status=404;body="Not found";}
            byte[] data=body.getBytes("UTF-8"); OutputStream out=socket.getOutputStream();
            out.write(("HTTP/1.1 "+status+" OK\r\nContent-Type: text/plain\r\nContent-Length: "+data.length+"\r\nConnection: close\r\n\r\n").getBytes("UTF-8")); out.write(data); out.flush();
        } catch(Exception ignored) {}
    }
    private boolean constantTime(String a,String b){byte[] x=a.getBytes(),y=b.getBytes();int diff=x.length^y.length;for(int i=0;i<Math.max(x.length,y.length);i++)diff|=(i<x.length?x[i]:0)^(i<y.length?y[i]:0);return diff==0;}

    private void show(int seconds) {
        if(!Settings.canDrawOverlays(this)) return;
        removeOverlay();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.BLACK);
        TextView heading=new TextView(this); heading.setText("  DOORBELL  •  CONNECTING..."); heading.setTextColor(Color.WHITE); heading.setTextSize(24); heading.setPadding(12,8,12,8); root.addView(heading);
        surface=new SurfaceView(this); root.addView(surface,new LinearLayout.LayoutParams(-1,0,1));
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,android.graphics.PixelFormat.OPAQUE);
        p.gravity=Gravity.CENTER; overlay=root;
        try{wm.addView(root,p);}catch(Exception e){android.util.Log.e("FireDoor","Overlay",e);overlay=null;return;}

        String stream=getSharedPreferences("MainActivity",0).getString("stream","");
        try {
            ArrayList<String> opts=new ArrayList<>(); opts.add("--rtsp-tcp"); opts.add("--network-caching=250"); opts.add("--clock-jitter=0"); opts.add("--clock-synchro=0");
            libVLC=new LibVLC(this,opts); player=new MediaPlayer(libVLC);
            player.getVLCVout().setVideoView(surface); player.getVLCVout().attachViews();
            player.setEventListener(event -> ui.post(() -> {
                if(event.type==MediaPlayer.Event.Playing) heading.setText("  DOORBELL  •  LIVE");
                else if(event.type==MediaPlayer.Event.EncounteredError) heading.setText("  DOORBELL  •  VIDEO ERROR");
            }));
            Media media=new Media(libVLC,android.net.Uri.parse(stream)); media.setHWDecoderEnabled(true,false); media.addOption(":rtsp-tcp"); media.addOption(":network-caching=250");
            player.setMedia(media); media.release(); player.play();
        } catch(Exception e){heading.setText("  DOORBELL  •  VLC ERROR");android.util.Log.e("FireDoor","VLC",e);}
        ui.removeCallbacks(hide); ui.postDelayed(hide,seconds*1000L);
    }
    private void removeOverlay() {
        ui.removeCallbacks(hide);
        if(player!=null){try{player.stop();player.getVLCVout().detachViews();player.release();}catch(Exception ignored){}player=null;}
        if(libVLC!=null){try{libVLC.release();}catch(Exception ignored){}libVLC=null;}
        surface=null;
        if(overlay!=null&&wm!=null){try{wm.removeView(overlay);}catch(Exception ignored){}overlay=null;}
    }
    @Override public void onDestroy(){try{if(server!=null)server.close();}catch(Exception ignored){}workers.shutdownNow();removeOverlay();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
